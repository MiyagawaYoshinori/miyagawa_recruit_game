﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//フェードインアウト実行
public class Fade : MonoBehaviour
{
    public float FadeSpeed;         //フェードの速度
    private float SpeedCounter;     //フェードの進行値
    public bool FadeMode;           //falseならフェードアウトtrueならフェードイン
    public Material material;        //フェードのマテリアル

    public GameObject StartCounter; 　//フェード後の演出のカウント

    private bool FadeEnd;

    void Start()
    {
        if (!FadeMode)
        {
            SpeedCounter = 0;
        }else{
            SpeedCounter = 1;
        }

        FadeEnd = false;
    }

    void Update()
    {
        if (!FadeMode)
        {
            //フェードアウトの処理
            SpeedCounter += FadeSpeed;

            if(SpeedCounter >= 1)
            {
                //ゲーム開始中のフェードアウト演出だった場合、カウント演出を生成する
                if (GameManager.Instance.GetStatus() == GameManager.GameStatus.Start)
                    Instantiate(StartCounter);

                Destroy(this.gameObject);
            }
            
        }else {
            //フェードインの処理
            SpeedCounter -= FadeSpeed;

            if (SpeedCounter <= 0)
            {
                FadeEnd = true;

                //Destroy(this.gameObject);
            }

        }

        //カウンタの数値をセットする
        material.SetFloat("_Alpha", SpeedCounter);
    }

    public bool GetFadeState()
    {
        return FadeEnd;
    }
}
