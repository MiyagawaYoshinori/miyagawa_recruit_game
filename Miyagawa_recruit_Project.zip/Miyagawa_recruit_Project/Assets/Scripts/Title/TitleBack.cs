﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//背景の調整
public class TitleBack: MonoBehaviour
{
    public Renderer TargetRender; //対象の背景
    public float ScrollSpeed;
    public Material material;      //背景のマテリアル

    void Start()
    {
    }

    void Update()
    {
        material.SetFloat("_Speed", ScrollSpeed);
    }
}
