﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//タイトルでの選択
public class Select : MonoBehaviour
{
    public enum SelectState
    {
        ScoreAttack,
        End,
    }

    private SelectState selectstate;

    public GameObject SelectObj;

    private bool EnterInput;        //Enterキーが押されたか検知

    public GameObject FadeObj;

    private GameObject FadeObject;  //演出検知用

    // Start is called before the first frame update
    void Start()
    {
        selectstate = SelectState.ScoreAttack;
        EnterInput = false;
    }

    // Update is called once per frame
    void Update()
    {
        //既に決定されている場合
        if (EnterInput)
        {
            //フェードスクリプトのステートを取得、フェード演出が終わったら選択されたステートを実行
            if (FadeObject.GetComponent<Fade>().GetFadeState())
            {
                switch (selectstate) {
                    case SelectState.End:
                        Application.Quit();
                        Debug.Log("GameEnd");
                        break;
                    case SelectState.ScoreAttack:
                        SceneManager.LoadScene("Main");
                        break;
                }

                
            }
            return;
        }

        //キー押下を検知した時
        if (Input.GetButtonDown("Horizontal"))
        {
            if(selectstate == SelectState.End)
            {
                selectstate = SelectState.ScoreAttack;
                SelectObj.transform.localPosition = new Vector3(0, -230, 0);
            }
            else{
                selectstate = SelectState.End;
                SelectObj.transform.localPosition = new Vector3(350, -230, 0);
            }
        }

        //決定キーを押したとき、
        if (Input.GetButtonDown("Enter"))
        {
            EnterInput = true;
            FadeObject = Instantiate(FadeObj);
            Debug.Log("Enter");
        }

    }

    //選択されている状態
    public SelectState GetSelect()
    {
        return selectstate;
    }

}
