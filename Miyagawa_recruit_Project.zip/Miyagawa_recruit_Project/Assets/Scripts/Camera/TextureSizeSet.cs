﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//解像度が元のものに合うようカメラを調整
public class TextureSizeSet : MonoBehaviour
{
    public Camera MainCamera;           //対象のメインカメラ
    public Vector2 DevelopCameraScreen; //開発してるときの解像度


    void Start()
    {
        //カメラの縦横の比率を取得
        float CameraScale = ((float)Screen.width / (float)Screen.height) / (DevelopCameraScreen.x / DevelopCameraScreen.y);

        //scaleを計算し、orthographicSizeを変更する
        float Scale = 1.0f / CameraScale;
        MainCamera.orthographicSize = MainCamera.orthographicSize * Scale;

    }

}
