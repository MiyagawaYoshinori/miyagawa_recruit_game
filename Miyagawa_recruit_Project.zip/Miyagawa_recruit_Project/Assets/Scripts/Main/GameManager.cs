﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//ゲーム進行を管理するマネージャー
public class GameManager : MonoBehaviour
{

    public static GameManager Instance;     //シングルトン
    private GameStatus gamestatus;          //ゲームの状態

    public GameObject GameUI;               //ゲームのUI

    public int EnemyLimit;                  //エネミーの上限
    public int EnemyPopTime;                //エネミーの追加時間
    private int EnemyPopCount;
    public GameObject[] EnemyObj;

    public GameObject TimeUpObj;

    //ゲームのステータス
    public enum GameStatus
    {
        Start,
        Play,
        Pause,
        End
    }

    void Awake()
    {
        Instance = this;
        SetStatus(GameStatus.Start);
        EnemyPopCount = EnemyPopTime;
    }

    void Update()
    {
        switch (gamestatus)
        {
            case GameStatus.Play:

                EnemyPop();

                break;
        }
    }

    //一定時間経過時エネミーを追加する
    private void EnemyPop()
    {
        EnemyPopCount--;
        //TODO:敵出現の上限の処理が必要
        if(EnemyPopCount <= 0)
        {
            int Rand = Random.Range(0, 3);
            Instantiate(EnemyObj[Rand]);

            EnemyPopCount = EnemyPopTime;
        }
    }

    //ゲームのステータスを変更する関数。また各ステータスの変更の際変更にあった内容を実行する。
    public void SetStatus(GameStatus Status)
    {
        gamestatus = Status;
        switch (Status)
        {
            case GameStatus.Start:
                StartStatus();
                break;
            case GameStatus.Play:
                PlayStatus();
                break;
            case GameStatus.Pause:
                //TODO:現在ポーズ画面の優先度は低。ゲームの本筋ができ次第実装
                PauseStatus();
                break;
            case GameStatus.End:
                EndStatus();
                break;
        }
    }

    //現在の状態を返す
    public GameStatus GetStatus()
    {
        return gamestatus;
    }

    //スタートされた時の処理
    private void StartStatus()
    {
        Debug.Log("Status:Start");
    }

    //プレイされた時の処理
    private void PlayStatus()
    {
        Instantiate(GameUI);
        Debug.Log("Status:Play");
    }

    //ポーズされた時の処理
    private void PauseStatus()
    {
        Debug.Log("Status:Pause");
    }

    //エンドされた時の処理
    private void EndStatus()
    {
        Instantiate(TimeUpObj);
        Debug.Log("Status:End");
    }
}
