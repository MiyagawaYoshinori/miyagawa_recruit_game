﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//背景の調整
public class BackGround : MonoBehaviour
{
    public Renderer TargetRender; //対象の背景
    public float ScrollSpeed;
    public Material material;      //背景のマテリアル

    void Start()
    {
        material.SetFloat("_Speed", 0);
    }

    void Update()
    {
        //ゲームステータスが条件に満たした場合、背景をスクロールさせる。
        if(GameManager.Instance.GetStatus() == GameManager.GameStatus.Start ||
           GameManager.Instance.GetStatus() == GameManager.GameStatus.Play)
        {
            material.SetFloat("_Speed", ScrollSpeed);
        }else{
            material.SetFloat("_Speed", 0);
        }
    }
}
