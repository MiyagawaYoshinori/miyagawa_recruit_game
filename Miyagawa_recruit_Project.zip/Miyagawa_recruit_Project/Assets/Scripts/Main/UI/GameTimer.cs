﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//ゲーム時間の管理
public class GameTimer : MonoBehaviour
{
    public Text  TimeText;
    public float GameTime;
    private int GameSecond;
    private bool TimeUp;

    void Start()
    {
        TimeUp = false;
    }

    void Update()
    {
        GameTime -= Time.deltaTime;
        GameSecond = (int)GameTime;

        if(GameSecond <= 0 && !TimeUp)
        {
            GameSecond = 0;
            TimeUp = true;
            GameManager.Instance.SetStatus(GameManager.GameStatus.End);
        }

        TimeText.text = GameSecond.ToString();

    }
}
