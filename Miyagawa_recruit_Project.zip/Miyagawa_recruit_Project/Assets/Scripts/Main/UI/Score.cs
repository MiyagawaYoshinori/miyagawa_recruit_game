﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//スコア
public class Score : MonoBehaviour
{
    public static Score Instance;   //シングルトン
    public Text ScoreText;
    private int ScoreNum;
    // Start is called before the first frame update
    void Awake()
    {
        Instance = this;
        ScoreNum = 0;
        ScoreText.text = "Score:　" + ScoreNum.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //スコアの追加
    public void AddScore(int Add)
    {
        ScoreNum += Add;
        ScoreText.text = "Score:　" + ScoreNum.ToString();
    }

    //スコアを指定した値にする
    public void SetScore(int Set)
    {
        ScoreNum = Set;
        ScoreText.text = "Score:　" + ScoreNum.ToString();
    }

    //スコアの状態を取得
    public int GetScore()
    {
        return ScoreNum;
    }
}
