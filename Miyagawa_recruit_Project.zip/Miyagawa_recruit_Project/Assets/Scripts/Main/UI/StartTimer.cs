﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//ゲームを開始するための処理
public class StartTimer : MonoBehaviour
{
    public Text StartText;      //スタートのテキスト
    public float StartTime;     //指定した値の秒数で開始
    private int SecondTime;     //テキスト表示用
    public float DestroyTime;   //文字表示後破棄する時間

    // Update is called once per frame
    void Update()
    {
        StartTime -= Time.deltaTime;
        SecondTime = (int)StartTime;

        if (SecondTime > 0) {

            StartText.text = SecondTime.ToString();
        }else{
            StartText.text = "GO!";

            DestroyTime -= Time.deltaTime;

            if(DestroyTime <= 0) {
                Destroy(this.gameObject);
                GameManager.Instance.SetStatus(GameManager.GameStatus.Play);
            }

        }
    }
}
