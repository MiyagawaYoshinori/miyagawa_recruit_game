﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//プレイヤーの制御、行動など
public class Player : MonoBehaviour
{
    public float StartSpeed;            //スタート時のプレイヤー機出現速度
    public float PlayerStartPositionY;  //プレイヤー機の開始地点

    public float PlayerSpeed;           //ゲーム中のプレイヤー速度

    public GameObject BulletObj;
    public int BulletDelayFrame;
    private int BulletDelayCount;

    // Start is called before the first frame update
    void Start()
    {
        BulletDelayCount = BulletDelayFrame;
    }

    // Update is called once per frame
    void Update()
    {
        //現在の状態を取得し、状態によってすべき処理をする
        switch (GameManager.Instance.GetStatus())
        {
            case GameManager.GameStatus.Start:

                PlayerStartMove();

                break;
            case GameManager.GameStatus.Play:

                SetPlayerPosition();        //移動

                PlayerAction();             //行動

                LimitPlayerPosition();      //制限

                break;

        }
    }

    //ゲーム開始直前のプレイヤーの動き
    private void PlayerStartMove()
    {
        float StartMove = transform.position.y + StartSpeed;

        StartMove = Mathf.Clamp(StartMove, -8, PlayerStartPositionY);

        transform.position = new Vector3 (transform.position.x, StartMove,0);
    }

    //プレイヤーの移動制御処理
    private void SetPlayerPosition()
    {
        Vector2 MovePosition;

        //X軸の制御
        MovePosition.x = Input.GetAxisRaw("Horizontal") * PlayerSpeed;

        //Y軸の制御
        MovePosition.y = Input.GetAxisRaw("Vertical") * PlayerSpeed;

        //制御を元にプレイヤー機体の位置を変更する
        transform.position += new Vector3(MovePosition.x, MovePosition.y, 0);

    }

    //プレイヤーの行動制御処理
    private void PlayerAction()
    {

        //弾関連の処理
        if(BulletDelayCount > 0)
            BulletDelayCount--;
        if (Input.GetButton("BulletFire"))
        {
            
            if(BulletDelayCount <= 0)
            {
                Instantiate(BulletObj, new Vector3(transform.position.x + 0.26f, transform.position.y + 0.5f, transform.position.z), Quaternion.identity);
                Instantiate(BulletObj, new Vector3(transform.position.x - 0.26f, transform.position.y + 0.5f, transform.position.z), Quaternion.identity);
                BulletDelayCount = BulletDelayFrame;
            }
        }

    }

    //プレイヤーの移動制限
    private void LimitPlayerPosition()
    {
        //左下のワールド座標を取得
        Vector2 LimitMin = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));

        //右上のワールド座標を取得
        Vector2 LimitMax = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));

        //プレイヤーの現在位置
        Vector2 PlayerPos = transform.position;

        //プレイヤーの位置の制限
        PlayerPos.x = Mathf.Clamp(PlayerPos.x, LimitMin.x, LimitMax.x);
        PlayerPos.y = Mathf.Clamp(PlayerPos.y, LimitMin.y, LimitMax.y);


        //制限の情報を反映させる
        transform.position = new Vector3(PlayerPos.x , PlayerPos.y , 0);
    }

}
