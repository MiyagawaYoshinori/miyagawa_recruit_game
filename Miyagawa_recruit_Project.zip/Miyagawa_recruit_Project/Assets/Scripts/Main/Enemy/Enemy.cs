﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//エネミーの処理
public class Enemy : MonoBehaviour
{
    public Vector2 LimitMoveMin;   //移動の最低幅
    public Vector2 LimitMoveMax;   //移動の最高幅

    private Vector2 PositionMove;
    public float MoveSpeed;       //移動速度
    public int   MoveTimeFrame;        //次移動する時間
    private int MoveTimeCount;

    public int DestroyPoint;        //得点

    void Start()
    {
        MoveTimeCount = MoveTimeFrame;
        SetRandomPosition();
    }

    void Update()
    {
        MoveTimeCount--;
        //時間が経ったら移動する
        if(MoveTimeCount <= 0)
        {
            SetRandomPosition();
        }

        RandomMove();

    }

    //
    private void SetRandomPosition()
    {
        PositionMove.x = Random.Range(LimitMoveMin.x, LimitMoveMax.x);
        PositionMove.y = Random.Range(LimitMoveMin.y, LimitMoveMax.y);

        MoveTimeCount = MoveTimeFrame;
    }

    private void RandomMove()
    {
        Vector2 MovePosition = transform.position;

        if(transform.position.x > PositionMove.x)
        {          
            MovePosition.x = transform.position.x - MoveSpeed;
            if (MovePosition.x < PositionMove.x)
                MovePosition.x = PositionMove.x;
        }
        else if (transform.position.x < PositionMove.x){
            MovePosition.x = transform.position.x + MoveSpeed;
            if (MovePosition.x > PositionMove.x)
                MovePosition.x = PositionMove.x;
        }

        if (transform.position.y > PositionMove.y)
        {
            MovePosition.y = transform.position.y - MoveSpeed;
            if (MovePosition.y < PositionMove.y)
                MovePosition.y = PositionMove.y;
        }
        else if(transform.position.y < PositionMove.y){
            MovePosition.y = transform.position.y + MoveSpeed;
            if (MovePosition.y > PositionMove.y)
                MovePosition.y = PositionMove.y;
        }

        transform.position = new Vector3(MovePosition.x, MovePosition.y, 0);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        // 弾を削除
        Destroy(collision.gameObject);

        //得点を追加
        Score.Instance.AddScore(DestroyPoint);

        // エネミーを削除
        Destroy(this.gameObject);
    }
}
